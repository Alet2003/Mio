//let table = new DataTable('#example');
// $(document).ready(function() {
//     $('#example').DataTable();
// } );
$.noConflict();
jQuery(document).ready(function() {
    jQuery('#example').DataTable();
  });